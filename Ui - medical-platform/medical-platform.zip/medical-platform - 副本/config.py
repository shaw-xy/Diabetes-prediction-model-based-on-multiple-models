import os
import secrets

class Config:
    # Basic Flask config
    # 使用固定的密钥，这是一个安全的随机生成的32字节密钥
    SECRET_KEY = os.environ.get('SECRET_KEY') or '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'
    DEBUG = False
    
    # File paths
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    DATASET_PATH = os.path.join(BASE_DIR, 'Dataset of Diabetes-V2.csv')
    
    # Security settings
    SESSION_COOKIE_SECURE = True
    REMEMBER_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_HTTPONLY = True
    
    # CORS settings
    CORS_HEADERS = 'Content-Type'
    
    # Upload settings
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
    
    # Cache settings
    CACHE_TYPE = 'simple'
    CACHE_DEFAULT_TIMEOUT = 300

class ProductionConfig(Config):
    # Production specific settings
    DEBUG = False
    TESTING = False
    
    # Add your production database URL here if needed
    # SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
    
    # Logging
    LOG_LEVEL = 'INFO'
    LOG_FILE = 'app.log'

class DevelopmentConfig(Config):
    # Development specific settings
    DEBUG = True
    TESTING = False
    
    # Logging
    LOG_LEVEL = 'DEBUG'
    LOG_FILE = 'dev.log'

# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
} 