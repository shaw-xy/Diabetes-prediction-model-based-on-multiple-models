from flask import Flask, jsonify, request, send_from_directory, render_template, redirect, url_for, session
from flask_cors import CORS
import subprocess
import sys
import os
import logging
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from datetime import datetime, timedelta
from database import verify_password, add_user, update_password, verify_security_info
import socket
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Set session key
CORS(app, resources={r"/*": {"origins": "*"}})  # Allow cross-origin requests

# Get current directory
current_dir = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(current_dir, 'Dataset of Diabetes-V2.csv')

# Example user data (should use database in production)
USERS = {
    'admin': {
        'password': 'admin',
        'email': 'admin@example.com',
        'phone': '13800138000',
        'security_questions': [
            {'question': 'father', 'answer': 'John'},
            {'question': 'mother', 'answer': 'Mary'},
            {'question': 'pet', 'answer': 'Spot'}
        ]
    },
    'test': {
        'password': 'test',
        'email': 'test@example.com',
        'phone': '13900139000',
        'security_questions': [
            {'question': 'father', 'answer': 'Tom'},
            {'question': 'mother', 'answer': 'Jane'},
            {'question': 'pet', 'answer': 'Max'}
        ]
    }
}

# Ensure necessary directories exist
for folder in ['static', 'templates', 'classify', 'assets']:
    folder_path = os.path.join(current_dir, folder)
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        logger.info(f"Created directory: {folder}")

@app.route('/')
def index():
    if 'username' in session:
        return render_template('dashboard.html', logged_in=True)
    return render_template('dashboard.html', logged_in=False)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')
    phone = data.get('phone')
    security_questions = data.get('securityQuestions')

    if not all([username, password, email, phone, security_questions]):
        return jsonify({'success': False, 'message': 'Please fill in all required fields'})

    if add_user(username, password, email, phone, security_questions):
        return jsonify({'success': True, 'message': 'Registration successful'})
    else:
        return jsonify({'success': False, 'message': 'Username already exists or registration failed'})

@app.route('/forgot-password')
def forgot_password():
    return render_template('forgot-password.html')

@app.route('/reset-password', methods=['POST'])
def reset_password():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    phone = data.get('phone')
    security_question = data.get('securityQuestion1')
    security_answer = data.get('securityAnswer1')
    new_password = data.get('newPassword')

    if not all([username, email, phone, security_question, security_answer, new_password]):
        return jsonify({'success': False, 'message': 'Please fill in all required fields'})

    if verify_security_info(username, email, phone, security_question, security_answer):
        if update_password(username, new_password):
            return jsonify({'success': True, 'message': 'Password reset successful'})
        else:
            return jsonify({'success': False, 'message': 'Password reset failed'})
    else:
        return jsonify({'success': False, 'message': 'Incorrect verification information'})

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if verify_password(username, password):
        session['username'] = username
        session.permanent = True
        app.permanent_session_lifetime = timedelta(minutes=30)
        return jsonify({'success': True})
    return jsonify({'success': False, 'message': 'Incorrect username or password'})

@app.route('/check-login')
def check_login():
    return jsonify({'logged_in': 'username' in session})

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.clear()
    response = jsonify({'success': True})
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

@app.route('/assets/<path:filename>')
def serve_asset(filename):
    return send_from_directory('assets', filename)

@app.route('/classify/<path:filename>')
def serve_image(filename):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    return send_from_directory('classify', filename)

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route('/predict-patient', methods=['GET', 'POST'])
def predict_patient():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
        
    try:
        # 根据请求方法获取数据
        if request.method == 'POST':
            data = request.json
        else:  # GET
            data = request.args.to_dict()
            
        logger.info(f"Received prediction request with data: {data}")
        
        method = data.pop('method', 'logistic')
        logger.info(f"Using prediction method: {method}")
        
        # 获取预测文件路径
        model_files = {
            'svm': 'svm.py',
            'random_forest': 'random_forest.py',
            'decision_tree': 'decision_tree.py',
            'logistic': 'logistic.py'
        }
        
        if method not in model_files:
            return jsonify({
                'success': False,
                'error': f"Invalid method: {method}"
            })
            
        python_file = os.path.join(current_dir, model_files[method])
            
        if not os.path.exists(python_file):
            return jsonify({
                'success': False,
                'error': f"Model file not found: {python_file}"
            })
            
        # 准备命令行参数
        cmd_args = [sys.executable, python_file]
        
        # 统一使用数据集中的列名作为参数名
        param_mapping = {
            'gender': str(data.get('gender', 'F')),
            'age': str(float(data.get('AGE', 0))),
            'urea': str(float(data.get('Urea', 0))),
            'cr': str(float(data.get('Cr', 0))),
            'hba1c': str(float(data.get('HbA1c', 0))),
            'chol': str(float(data.get('Chol', 0))),
            'tg': str(float(data.get('TG', 0))),
            'hdl': str(float(data.get('HDL', 0))),
            'ldl': str(float(data.get('LDL', 0))),
            'vldl': str(float(data.get('VLDL', 0))),
            'bmi': str(float(data.get('BMI', 0)))
        }
        
        # 添加命令行参数
        for param, value in param_mapping.items():
            cmd_args.extend([f'--{param}', value])
            
        logger.info(f"Command arguments: {' '.join(cmd_args)}")
        
        # 执行预测
        result = subprocess.run(
            cmd_args,
            capture_output=True,
            text=True,
            cwd=current_dir
        )
        
        if result.returncode != 0:
            error_msg = result.stderr.strip()
            logger.error(f"Prediction error: {error_msg}")
            return jsonify({
                'success': False,
                'error': f"Prediction failed: {error_msg}"
            })
            
        # 解析输出结果
        try:
            output = result.stdout.strip()
            logger.info(f"Model output: {output}")
            
            if not output:
                raise ValueError("Empty output from model")
                
            prediction_result = json.loads(output)
            prediction = prediction_result.get('prediction', 'N')
            # 如果预测为 'N'，使用负类的概率；如果预测为 'Y'，使用正类的概率
            probability = prediction_result.get('probability', 0.0)
            if prediction == 'N':
                probability = 1.0 - probability  # 取反类的概率
            
            return jsonify({
                'success': True,
                'prediction': prediction,
                'probability': probability
            })
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing model output: {output}")
            return jsonify({
                'success': False,
                'error': f"Invalid model output format: {str(e)}"
            })
        except Exception as e:
            logger.error(f"Error processing model output: {str(e)}")
            return jsonify({
                'success': False,
                'error': f"Error processing model output: {str(e)}"
            })
            
    except Exception as e:
        logger.error(f"Error in prediction: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/run-prediction', methods=['GET'])
def run_prediction():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
        
    try:
        method = request.args.get('method', 'logistic')
        logger.info(f"Received prediction request for method: {method}")
        
        # 获取预测文件路径
        model_files = {
            'svm': 'svm.py',
            'random_forest': 'random_forest.py',
            'decision_tree': 'decision_tree.py',
            'logistic': 'logistic.py'
        }
        
        if method not in model_files:
            return jsonify({
                'success': False,
                'error': f"Invalid method: {method}"
            })
            
        python_file = os.path.join(current_dir, model_files[method])
            
        if not os.path.exists(python_file):
            return jsonify({
                'success': False,
                'error': f"Model file not found: {python_file}"
            })
            
        # 运行预测模型评估
        result = subprocess.run(
            [sys.executable, python_file, '--evaluate'],
            capture_output=True,
            text=True,
            cwd=current_dir
        )
        
        # 检查是否有错误输出
        if result.stderr:
            logger.error(f"Model error output: {result.stderr}")
            try:
                error_data = json.loads(result.stderr)
                return jsonify({
                    'success': False,
                    'error': error_data.get('error', 'Unknown error'),
                    'type': error_data.get('type', 'UnknownError')
                })
            except json.JSONDecodeError:
                return jsonify({
                    'success': False,
                    'error': result.stderr
                })
        
        # 处理标准输出
        try:
            output = result.stdout.strip()
            if not output:
                return jsonify({
                    'success': False,
                    'error': 'No output from model'
                })
                
            model_result = json.loads(output)
            return jsonify(model_result)
            
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing model output: {output}")
            return jsonify({
                'success': False,
                'error': f"Invalid model output format: {str(e)}"
            })
            
    except Exception as e:
        error_msg = f"Error during prediction: {str(e)}"
        logger.error(error_msg)
        return jsonify({
            'success': False,
            'error': error_msg
        })

if __name__ == '__main__':
    local_ip = socket.gethostbyname(socket.gethostname())
    port = 5000
    
    print("\n" + "="*50)
    print("Medical Health Platform Server Started!")
    print("="*50)
    print(f"Local access: http://localhost:{port}")
    print(f"LAN access: http://{local_ip}:{port}")
    print(f"External access note: Please set up port forwarding in your router, mapping external port {port} to {local_ip}:{port}")
    print("="*50 + "\n")
    
    app.run(host='0.0.0.0', port=port, debug=True) 