import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import os
import json
import sys
import argparse

def evaluate_model():
    try:
        # 获取当前文件所在目录
        current_dir = os.path.dirname(os.path.abspath(__file__))
        dataset_path = os.path.join(current_dir, 'Dataset of Diabetes-V2.csv')

        if not os.path.exists(dataset_path):
            result = {
                'success': False,
                'error': f"Dataset not found at: {dataset_path}",
                'type': 'FileNotFoundError'
            }
            print(json.dumps(result))
            return

        # 读取数据
        df = pd.read_csv(dataset_path)
        
        # 处理性别列
        df['Gender'] = df['Gender'].map({'M': 1, 'F': 0})
        
        # 准备特征和目标变量
        feature_columns = ['Gender', 'AGE', 'Urea', 'Cr', 'HbA1c', 'Chol', 'TG', 'HDL', 'LDL', 'VLDL', 'BMI']
        X = df[feature_columns].copy()
        y = pd.Series([1 if val == 'Y' else 0 for val in df['CLASS']], index=df.index)
        
        # 处理可能的缺失值
        X = X.fillna(X.mean())
        y = y.fillna(0)
        
        # 划分训练集和测试集
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # 标准化特征
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # 训练模型
        model = DecisionTreeClassifier(random_state=42)
        model.fit(X_train_scaled, y_train)
        
        # 预测
        y_pred = model.predict(X_test_scaled)
        
        # 计算各项指标
        metrics = {
            'accuracy': float(accuracy_score(y_test, y_pred)),
            'precision': float(precision_score(y_test, y_pred)),
            'recall': float(recall_score(y_test, y_pred)),
            'f1': float(f1_score(y_test, y_pred))
        }
        
        # 获取特征重要性
        feature_importance = dict(zip(feature_columns, model.feature_importances_.tolist()))
        feature_importance = dict(sorted(feature_importance.items(), key=lambda x: x[1], reverse=True))
        
        # 构建输出结果
        result = {
            'success': True,
            'metrics': metrics,
            'feature_importance': feature_importance
        }
        
        # 输出JSON格式的结果
        print(json.dumps(result))
        
    except Exception as e:
        error_result = {
            'success': False,
            'error': str(e),
            'type': type(e).__name__
        }
        print(json.dumps(error_result))

def predict_diabetes():
    try:
        parser = argparse.ArgumentParser(description='Predict diabetes using Decision Tree')
        parser.add_argument('--evaluate', action='store_true', help='Evaluate the model')
        
        # 添加预测所需的参数
        parser.add_argument('--gender', type=str, required=False)
        for feature in ['age', 'urea', 'cr', 'hba1c', 'chol', 'tg', 'hdl', 'ldl', 'vldl', 'bmi']:
            parser.add_argument(f'--{feature}', type=float, required=False)
        
        args = parser.parse_args()
        
        if args.evaluate:
            return evaluate_model()
        
        # 检查参数
        required_features = ['gender', 'age', 'urea', 'cr', 'hba1c', 'chol', 'tg', 'hdl', 'ldl', 'vldl', 'bmi']
        missing_features = [f for f in required_features if getattr(args, f) is None]
        if missing_features:
            return json.dumps({
                'success': False,
                'error': f'Missing required features: {", ".join(missing_features)}'
            })
        
        # 准备输入数据
        input_data = pd.DataFrame({
            'Gender': [1 if args.gender.upper() == 'M' else 0],
            'AGE': [args.age],
            'Urea': [args.urea],
            'Cr': [args.cr],
            'HbA1c': [args.hba1c],
            'Chol': [args.chol],
            'TG': [args.tg],
            'HDL': [args.hdl],
            'LDL': [args.ldl],
            'VLDL': [args.vldl],
            'BMI': [args.bmi]
        })
        
        # 加载训练数据
        current_dir = os.path.dirname(os.path.abspath(__file__))
        dataset_path = os.path.join(current_dir, 'Dataset of Diabetes-V2.csv')
        
        if not os.path.exists(dataset_path):
            error_result = {
                'success': False,
                'error': f"Dataset not found at: {dataset_path}",
                'type': 'FileNotFoundError'
            }
            print(json.dumps(error_result))
            return
            
        df = pd.read_csv(dataset_path)
        
        # 处理性别列
        df['Gender'] = df['Gender'].map({'M': 1, 'F': 0})
        
        # 准备特征和目标变量
        feature_columns = ['Gender', 'AGE', 'Urea', 'Cr', 'HbA1c', 'Chol', 'TG', 'HDL', 'LDL', 'VLDL', 'BMI']
        X = df[feature_columns].copy()
        y = pd.Series([1 if val == 'Y' else 0 for val in df['CLASS']], index=df.index)
        
        # 处理可能的缺失值
        X = X.fillna(X.mean())
        y = y.fillna(0)
        
        # 数据标准化
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # 训练模型
        model = DecisionTreeClassifier(random_state=42)
        model.fit(X_scaled, y)
        
        # 对输入数据进行标准化
        input_scaled = scaler.transform(input_data)
        
        # 获取预测概率
        proba = model.predict_proba(input_scaled)[0]
        prediction = model.predict(input_scaled)[0]
        
        # 准备输出结果
        result = {
            'success': True,
            'prediction': 'Y' if prediction == 1 else 'N',
            'probability': float(proba[1]),  # 获取正类的概率
            'input_features': {
                'gender': args.gender,
                'age': args.age,
                'urea': args.urea,
                'cr': args.cr,
                'hba1c': args.hba1c,
                'chol': args.chol,
                'tg': args.tg,
                'hdl': args.hdl,
                'ldl': args.ldl,
                'vldl': args.vldl,
                'bmi': args.bmi
            }
        }
        
        # 输出JSON格式的结果
        print(json.dumps(result))
        
    except Exception as e:
        error_result = {
            'success': False,
            'error': str(e),
            'type': type(e).__name__
        }
        print(json.dumps(error_result))

if __name__ == '__main__':
    predict_diabetes() 