import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import json
import sys
import argparse
import os

def evaluate_model():
    try:
        dataset_path = 'Dataset of Diabetes-V2.csv'
        if not os.path.exists(dataset_path):
            return json.dumps({
                'success': False,
                'error': f'Dataset file not found: {dataset_path}'
            })

        # 读取数据集
        df = pd.read_csv(dataset_path)
        
        # 处理性别列
        df['Gender'] = df['Gender'].map({'M': 1, 'F': 0})
        
        # 准备特征和目标变量
        features = ['Gender', 'AGE', 'Urea', 'Cr', 'HbA1c', 'Chol', 'TG', 'HDL', 'LDL', 'VLDL', 'BMI']
        X = df[features]
        y = pd.Series([1 if val == 'Y' else 0 for val in df['CLASS']], index=df.index)
        
        # 处理缺失值
        X = X.fillna(X.median())
        y = y.fillna(0)
        
        # 分割数据集
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # 标准化特征
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # 创建和训练模型
        model = LogisticRegression(
            random_state=42,
            max_iter=1000,
            class_weight='balanced'
        )
        
        # 进行交叉验证
        cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=5)
        
        # 训练最终模型
        model.fit(X_train_scaled, y_train)
        
        # 预测
        y_pred = model.predict(X_test_scaled)
        
        # 计算性能指标
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        conf_matrix = confusion_matrix(y_test, y_pred)
        
        # 计算特征重要性
        importances = np.abs(model.coef_[0])
        
        # 创建特征重要性图表
        plt.figure(figsize=(10, 6))
        importance_df = pd.DataFrame({
            'Feature': features,
            'Importance': importances
        }).sort_values('Importance', ascending=True)
        
        sns.barplot(data=importance_df, x='Importance', y='Feature')
        plt.title('Feature Importance in Logistic Regression Model')
        plt.xlabel('Importance Score')
        
        # 保存图表
        plot_path = os.path.join('static', 'feature_importance.png')
        os.makedirs(os.path.dirname(plot_path), exist_ok=True)
        plt.savefig(plot_path)
        plt.close()
        
        # 准备返回结果
        result = {
            'success': True,
            'metrics': {
                'accuracy': float(accuracy),
                'precision': float(precision),
                'recall': float(recall),
                'f1_score': float(f1),
                'cv_scores_mean': float(cv_scores.mean()),
                'cv_scores_std': float(cv_scores.std()),
                'confusion_matrix': conf_matrix.tolist()
            },
            'feature_importance': {
                features[i]: float(importances[i]) for i in range(len(features))
            },
            'plot_path': plot_path
        }
        
        return json.dumps(result)
        
    except Exception as e:
        return json.dumps({
            'success': False,
            'error': str(e)
        })

def predict_diabetes():
    try:
        parser = argparse.ArgumentParser(description='Predict diabetes using Logistic Regression')
        parser.add_argument('--evaluate', action='store_true', help='Evaluate the model')
        
        # 添加预测所需的参数
        parser.add_argument('--gender', type=str, required=False)
        for feature in ['age', 'urea', 'cr', 'hba1c', 'chol', 'tg', 'hdl', 'ldl', 'vldl', 'bmi']:
            parser.add_argument(f'--{feature}', type=float, required=False)
        
        args = parser.parse_args()
        
        if args.evaluate:
            return evaluate_model()
        
        # 检查参数
        required_features = ['gender', 'age', 'urea', 'cr', 'hba1c', 'chol', 'tg', 'hdl', 'ldl', 'vldl', 'bmi']
        missing_features = [f for f in required_features if getattr(args, f) is None]
        if missing_features:
            return json.dumps({
                'success': False,
                'error': f'Missing required features: {", ".join(missing_features)}'
            })
        
        # 将性别转换为数值
        gender_value = 1 if args.gender.upper() == 'M' else 0
        
        # 准备输入数据
        input_data = pd.DataFrame([[
            gender_value, args.age, args.urea, args.cr, args.hba1c,
            args.chol, args.tg, args.hdl, args.ldl, args.vldl, args.bmi
        ]], columns=['Gender', 'AGE', 'Urea', 'Cr', 'HbA1c', 'Chol', 'TG', 'HDL', 'LDL', 'VLDL', 'BMI'])
        
        # 加载和预处理训练数据
        df = pd.read_csv('Dataset of Diabetes-V2.csv')
        df['Gender'] = df['Gender'].map({'M': 1, 'F': 0})
        X = df[input_data.columns]
        y = pd.Series([1 if val == 'Y' else 0 for val in df['CLASS']], index=df.index)
        
        # 处理缺失值
        X = X.fillna(X.median())
        y = y.fillna(0)
        
        # 标准化数据
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        input_scaled = scaler.transform(input_data)
        
        # 创建和训练模型
        model = LogisticRegression(
            random_state=42,
            max_iter=1000,
            class_weight='balanced'
        )
        
        # 训练模型并预测
        model.fit(X_scaled, y)
        prediction = model.predict(input_scaled)[0]
        probabilities = model.predict_proba(input_scaled)[0]
        
        # 准备预测结果
        prediction_result = {
            'success': True,
            'prediction': 'Y' if prediction == 1 else 'N',
            'probability': float(probabilities[1]),  # 使用正类（Y类）的概率作为置信度
            'probabilities': {
                'N': float(probabilities[0]),
                'Y': float(probabilities[1])
            }
        }
        
        return json.dumps(prediction_result)
        
    except Exception as e:
        return json.dumps({
            'success': False,
            'error': str(e)
        })

if __name__ == '__main__':
    print(predict_diabetes())



