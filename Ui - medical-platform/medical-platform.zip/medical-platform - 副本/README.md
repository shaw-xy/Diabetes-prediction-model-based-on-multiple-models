# Medical Health Platform

A comprehensive medical health platform for diabetes prediction using multiple machine learning models.

## Features

- User Authentication System
  - Login/Register functionality
  - Password recovery
  - Session management
  - User data persistence using SQLite

- Multiple Machine Learning Models
  - Support Vector Machine (SVM)
  - Random Forest
  - Decision Tree
  - Logistic Regression

- Interactive Dashboard
  - Real-time prediction
  - Model accuracy preview
  - Visual result presentation
  - User-friendly interface

## Project Structure

```
medical-platform/
├── app.py                 # Main Flask application
├── config.py             # Configuration settings
├── database.py           # Database operations
├── Dataset of Diabetes-V2.csv  # Training dataset
├── requirements.txt      # Python dependencies
│
├── ML Models
│   ├── svm.py           # SVM model implementation
│   ├── random_forest.py # Random Forest model
│   ├── decision_tree.py # Decision Tree model
│   └── logistic.py      # Logistic Regression model
│
├── static/
│   ├── script.js        # Main JavaScript file
│   ├── styles.css       # Main CSS file
│   └── images/          # Static images
│
├── templates/
│   ├── index.html       # Login page
│   ├── dashboard.html   # Main dashboard
│   ├── register.html    # Registration page
│   └── forgot-password.html  # Password recovery
│
└── classify/            # Classification result images
```

## Installation

1. Clone the repository
2. Create a virtual environment:
   ```bash
   python -m venv venv
   ```
3. Activate the virtual environment:
   - Windows: `venv\Scripts\activate`
   - Unix/MacOS: `source venv/bin/activate`
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Configuration

1. Ensure all required Python packages are installed
2. Configure the database settings in `config.py`
3. Make sure the dataset file is present in the root directory

## Usage

1. Start the Flask application:
   ```bash
   python app.py
   ```
2. Access the application through a web browser at `http://localhost:5000`
3. Register a new account or login with existing credentials
4. Use the dashboard to:
   - Select a prediction model
   - Input patient data
   - View prediction results
   - Check model accuracy

## Machine Learning Models

The platform includes four different machine learning models for diabetes prediction:

1. SVM (Support Vector Machine)
   - High accuracy for binary classification
   - Effective with high-dimensional data

2. Random Forest
   - Ensemble learning method
   - Good at handling missing values
   - Provides feature importance

3. Decision Tree
   - Simple and interpretable
   - Handles both numerical and categorical data

4. Logistic Regression
   - Basic but effective
   - Good for understanding feature relationships

## Dataset

The platform uses the Diabetes Dataset V2 which includes the following features:
- Gender
- Age
- Urea
- Cr
- HbA1c
- Chol
- TG
- HDL
- LDL
- VLDL
- BMI

## Security Features

- Password hashing
- Session management
- Input validation
- Error handling
- Secure database operations

## Dependencies

See `requirements.txt` for a complete list of Python dependencies.

## Browser Support

- Chrome (recommended)
- Firefox
- Safari
- Edge

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License.

## 版权信息
© 2025 医疗健康平台 版权所有 