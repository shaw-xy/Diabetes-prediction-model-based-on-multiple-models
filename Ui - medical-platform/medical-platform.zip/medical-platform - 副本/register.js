document.addEventListener('DOMContentLoaded', function() {
    // 清除现有的所有用户数据
    localStorage.removeItem('users');

    const form = document.getElementById('registerForm');
    
    // 密码显示/隐藏功能
    document.querySelectorAll('.toggle-password').forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault(); // 防止表单提交
            
            // 获取对应的密码输入框
            const targetId = this.getAttribute('data-target');
            const passwordInput = document.getElementById(targetId);

            // 切换密码显示/隐藏
            const type = passwordInput.type === 'password' ? 'text' : 'password';
            passwordInput.type = type;

            // 切换图标
            this.classList.toggle('fa-eye-slash');
            this.classList.toggle('fa-eye');
        });
    });

    // 密保问题选择验证
    const questions = [document.getElementById('question1'), 
                      document.getElementById('question2'), 
                      document.getElementById('question3')];
    
    questions.forEach(select => {
        select.addEventListener('change', function() {
            const selectedValue = this.value;
            questions.forEach(otherSelect => {
                if (otherSelect !== this && otherSelect.value === selectedValue) {
                    alert('请选择不同的密保问题！');
                    this.value = '';
                }
            });
        });
    });
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;
        
        // 获取密保问题
        const question1 = document.getElementById('question1').value;
        const answer1 = document.getElementById('answer1').value;
        const question2 = document.getElementById('question2').value;
        const answer2 = document.getElementById('answer2').value;
        const question3 = document.getElementById('question3').value;
        const answer3 = document.getElementById('answer3').value;

        // 表单验证
        if (!username || !password || !confirmPassword || !email || !phone) {
            alert('请填写所有必填项！');
            return;
        }

        // 密码验证
        if (password !== confirmPassword) {
            alert('两次输入的密码不一致！');
            return;
        }

        // 邮箱格式验证
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('请输入有效的邮箱地址！');
            return;
        }

        // 手机号格式验证
        const phoneRegex = /^1[3-9]\d{9}$/;
        if (!phoneRegex.test(phone)) {
            alert('请输入有效的手机号码！');
            return;
        }

        // 验证密保问题是否重复
        if (question1 === question2 || question2 === question3 || question1 === question3) {
            alert('请选择不同的密保问题！');
            return;
        }

        // 获取现有用户数据
        let users = JSON.parse(localStorage.getItem('users')) || [];
        
        // 检查用户名是否已存在
        if (users.some(user => user.username === username)) {
            alert('用户名已存在！');
            return;
        }

        // 创建新用户对象
        const newUser = {
            username,
            password,
            email,
            phone,
            securityQuestions: [
                { question: question1, answer: answer1 },
                { question: question2, answer: answer2 },
                { question: question3, answer: answer3 }
            ]
        };

        // 添加新用户到用户列表
        users.push(newUser);
        
        // 保存更新后的用户数据
        localStorage.setItem('users', JSON.stringify(users));
        
        alert('注册成功！');
        window.location.href = 'index.html';
    });
}); 