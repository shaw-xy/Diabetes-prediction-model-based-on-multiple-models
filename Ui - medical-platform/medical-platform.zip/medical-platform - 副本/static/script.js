// 全局变量
let selectedMethod = 'logistic';
let inactivityTimer;
const INACTIVITY_TIMEOUT = 30 * 60 * 1000; // 30分钟超时

// 获取当前服务器地址
function getServerUrl() {
    return window.location.origin;
}

// 检查登录状态
function checkLoginStatus() {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        window.location.href = '/';
        return false;
    }
    return true;
}

// 重置不活动计时器
function resetInactivityTimer() {
    clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(logout, INACTIVITY_TIMEOUT);
}

// 添加用户活动监听器
function addActivityListeners() {
    ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
        document.addEventListener(event, resetInactivityTimer);
    });
}

// 初始化页面
document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname !== '/' && window.location.pathname !== '/index.html') {
        if (!checkLoginStatus()) {
            return;
        }
        addActivityListeners();
        resetInactivityTimer();
    }
});

// 显示预测模型精确度预览部分
function showPredictionSection() {
    if (!checkLoginStatus()) return;
    document.getElementById('predictionSection').style.display = 'block';
    document.getElementById('diabetesPredictionSection').style.display = 'none';
}

// 显示糖尿病预测部分
function showDiabetesPrediction() {
    if (!checkLoginStatus()) return;
    document.getElementById('predictionSection').style.display = 'none';
    document.getElementById('diabetesPredictionSection').style.display = 'block';
}

// 隐藏预测部分
function hidePredictionSection() {
    document.getElementById('predictionSection').style.display = 'none';
}

// 隐藏糖尿病预测部分
function hideDiabetesPredictionSection() {
    document.getElementById('diabetesPredictionSection').style.display = 'none';
}

// 运行预测模型精确度预览
async function runPrediction(method) {
    if (!checkLoginStatus()) return;
    const predictionResult = document.getElementById('predictionResult');
    const loading = document.querySelector('.loading');
    loading.style.display = 'block';
    predictionResult.innerHTML = '';
    
    try {
        const response = await fetch(`/run-prediction?method=${method}`);
        const data = await response.json();
        
        if (data.success) {
            predictionResult.innerHTML = `<pre>${data.output}</pre>`;
        } else {
            predictionResult.innerHTML = `<div class="alert alert-danger">预测出错: ${data.error}</div>`;
        }
    } catch (error) {
        predictionResult.innerHTML = `<div class="alert alert-danger">请求失败: ${error.message}</div>`;
    } finally {
        loading.style.display = 'none';
    }
}

// 显示预测表单
function showPredictionForm(method) {
    if (!checkLoginStatus()) return;
    window.currentMethod = method;
    document.getElementById('predictionForm').classList.remove('hidden');
    document.getElementById('predictionResult2').textContent = '';
    document.getElementById('resultImage').classList.add('hidden');
}

// 预测患者数据
async function submitPrediction(event) {
    if (!checkLoginStatus()) return;
    event.preventDefault();
    const loading = document.querySelector('.loading');
    const resultDiv = document.getElementById('predictionResult2');
    const resultImage = document.getElementById('resultImage');
    const form = event.target;
    
    loading.style.display = 'block';
    resultDiv.textContent = '';
    resultImage.innerHTML = '';
    resultImage.classList.add('hidden');
    
    try {
        const formData = {
            method: window.currentMethod,
            AGE: parseFloat(form.age.value),
            Urea: parseFloat(form.urea.value),
            Cr: parseFloat(form.cr.value),
            HbA1c: parseFloat(form.hba1c.value),
            Chol: parseFloat(form.chol.value),
            TG: parseFloat(form.tg.value),
            HDL: parseFloat(form.hdl.value),
            LDL: parseFloat(form.ldl.value),
            VLDL: parseFloat(form.vldl.value),
            BMI: parseFloat(form.bmi.value)
        };

        const response = await fetch('/predict-patient', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });

        const result = await response.json();

        if (result.success) {
            resultDiv.innerHTML = `
                <div class="alert ${result.prediction === 'Y' ? 'alert-warning' : 'alert-success'}">
                    <h4>预测结果</h4>
                    <p>该患者${result.prediction === 'Y' ? '可能患有' : '可能没有'}糖尿病。</p>
                </div>
            `;
            
            // 显示对应的图片
            resultImage.classList.remove('hidden');
            resultImage.style.display = 'block';
            const imagePath = result.prediction === 'Y' ? 
                '/classify/diabetes.png' : 
                '/classify/normal.jpg';
            
            const img = new Image();
            img.onload = function() {
                resultImage.innerHTML = '';
                resultImage.appendChild(this);
            };
            img.onerror = function() {
                resultImage.innerHTML = '图片加载失败';
                console.error('Error loading image:', this.src);
            };
            img.src = imagePath;
            img.alt = result.prediction === 'Y' ? '糖尿病预测结果' : '正常预测结果';
            img.style.maxWidth = '100%';
            img.style.height = 'auto';
            img.style.borderRadius = '8px';
            img.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.1)';
        } else {
            resultDiv.innerHTML = `
                <div class="alert alert-danger">
                    <h4>错误</h4>
                    <p>${result.error}</p>
                </div>
            `;
        }
    } catch (error) {
        resultDiv.innerHTML = `
            <div class="alert alert-danger">
                <h4>错误</h4>
                <p>预测过程中出现错误: ${error.message}</p>
            </div>
        `;
    } finally {
        loading.style.display = 'none';
    }
}

// 登录函数
async function login(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(getServerUrl() + '/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password })
        });

        const result = await response.json();
        
        if (result.success) {
            localStorage.setItem('currentUser', result.username);
            window.location.href = '/dashboard';
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('登录失败: ' + error.message);
    }
}

// 注册函数
async function register(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const email = document.getElementById('email').value;
    
    if (password !== confirmPassword) {
        alert('两次输入的密码不一致');
        return;
    }
    
    try {
        const response = await fetch(getServerUrl() + '/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password, email })
        });

        const result = await response.json();
        
        if (result.success) {
            alert('注册成功！请登录。');
            window.location.href = '/';
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Registration error:', error);
        alert('注册失败: ' + error.message);
    }
}

// 退出登录
function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '/';
} 