document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const passwordInput = document.getElementById('password');
    let inactivityTimer;
    const INACTIVITY_TIMEOUT = 30 * 60 * 1000; // 30分钟超时

    // 检查是否已登录
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
        window.location.replace('dashboard.html#prediction');
        return;
    }

    // 登录表单提交处理
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = passwordInput.value;

            // 从localStorage获取用户数据
            const users = JSON.parse(localStorage.getItem('users')) || [];
            const user = users.find(u => u.username === username && u.password === password);

            if (user) {
                // 登录成功
                localStorage.setItem('currentUser', JSON.stringify(user));
                window.location.replace('dashboard.html#prediction');
            } else {
                alert('用户名或密码错误！');
            }
        });
    }

    // 密码显示/隐藏功能
    const togglePassword = document.querySelector('.toggle-password');
    
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function(e) {
            e.preventDefault();
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            const icon = this.querySelector('i');
            icon.classList.toggle('fa-eye-slash');
            icon.classList.toggle('fa-eye');
        });
    }

    // 重置不活动计时器
    function resetInactivityTimer() {
        clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(logout, INACTIVITY_TIMEOUT);
    }

    // 登出函数
    function logout() {
        // 清除所有相关的localStorage数据
        localStorage.removeItem('currentUser');
        localStorage.removeItem('lastActivity');
        localStorage.removeItem('predictionResults');
        // 重置所有状态
        if (document.getElementById('username')) {
            document.getElementById('username').value = '';
        }
        if (document.getElementById('password')) {
            document.getElementById('password').value = '';
        }
        // 清除计时器
        clearTimeout(inactivityTimer);
        // 跳转到登录页
        window.location.href = 'index.html';
    }

    // 添加用户活动监听器
    function addActivityListeners() {
        ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
            document.addEventListener(event, resetInactivityTimer);
        });
    }

    // 初始化活动监听器和计时器
    addActivityListeners();
    resetInactivityTimer();

    // 输入框焦点效果
    const usernameInput = document.getElementById('username');
    usernameInput.addEventListener('focus', function() {
        this.parentElement.classList.add('focused');
    });
    usernameInput.addEventListener('blur', function() {
        this.parentElement.classList.remove('focused');
    });
    passwordInput.addEventListener('focus', function() {
        this.parentElement.classList.add('focused');
    });
    passwordInput.addEventListener('blur', function() {
        this.parentElement.classList.remove('focused');
    });

    // 社交登录处理
    document.querySelectorAll('.social-icon').forEach(icon => {
        icon.addEventListener('click', function(e) {
            e.preventDefault();
            const platform = this.dataset.platform;
            
            switch(platform) {
                case 'wechat':
                    // 模拟微信登录
                    alert('正在跳转到微信登录...');
                    // 实际项目中这里应该调用微信登录API
                    break;
                case 'qq':
                    // 模拟QQ登录
                    alert('正在跳转到QQ登录...');
                    // 实际项目中这里应该调用QQ登录API
                    break;
                case 'google':
                    // 模拟Google登录
                    alert('正在跳转到Google登录...');
                    // 实际项目中这里应该调用Google登录API
                    break;
            }
        });
    });

    // 验证用户信息
    function verifyUser(username, password) {
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        return users.some(user => user.username === username && user.password === password);
    }

    // 社交账号登录验证
    function verifySocialLogin(platform, socialId) {
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        return users.find(user => user.socialAccounts[platform] === socialId);
    }

    // 显示预测结果
    function showPredictionResult(method) {
        const loadingElement = document.querySelector('.loading');
        const predictionResult = document.querySelector('.prediction-result');
        
        loadingElement.style.display = 'block';
        predictionResult.style.display = 'none';
        
        fetch(`/run-prediction?method=${method}`)
            .then(response => response.json())
            .then(data => {
                loadingElement.style.display = 'none';
                predictionResult.style.display = 'block';
                
                if (data.success) {
                    predictionResult.textContent = data.output;
                } else {
                    predictionResult.textContent = `Error: ${data.error}`;
                }
            })
            .catch(error => {
                loadingElement.style.display = 'none';
                predictionResult.style.display = 'block';
                predictionResult.textContent = `Error: ${error.message}`;
            });
    }

    // 处理表单提交
    document.querySelector('form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const loadingElement = document.querySelector('.loading');
        const predictionResult = document.querySelector('.prediction-result');
        const resultImage = document.querySelector('.result-image');
        
        loadingElement.style.display = 'block';
        predictionResult.style.display = 'none';
        resultImage.innerHTML = '';
        
        // 获取所有输入数据
        const data = {
            method: document.getElementById('method').value,
            AGE: parseFloat(document.getElementById('age').value),
            Urea: parseFloat(document.getElementById('urea').value),
            Cr: parseFloat(document.getElementById('cr').value),
            HbA1c: parseFloat(document.getElementById('hba1c').value),
            Chol: parseFloat(document.getElementById('chol').value),
            TG: parseFloat(document.getElementById('tg').value),
            HDL: parseFloat(document.getElementById('hdl').value),
            LDL: parseFloat(document.getElementById('ldl').value),
            VLDL: parseFloat(document.getElementById('vldl').value),
            BMI: parseFloat(document.getElementById('bmi').value)
        };
        
        // 发送预测请求
        fetch('/predict-patient', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            loadingElement.style.display = 'none';
            predictionResult.style.display = 'block';
            
            if (data.success) {
                const result = data.prediction === 'Y' ? '有患糖尿病风险' : '无患糖尿病风险';
                predictionResult.textContent = `预测结果：${result}`;
                
                // 显示对应的图片
                const imgSrc = data.prediction === 'Y' ? 'classify/diabetes.png' : 'classify/normal.jpg';
                resultImage.innerHTML = `<img src="${imgSrc}" alt="预测结果图片">`;
            } else {
                predictionResult.textContent = `预测出错：${data.error}`;
            }
        })
        .catch(error => {
            loadingElement.style.display = 'none';
            predictionResult.style.display = 'block';
            predictionResult.textContent = `发生错误：${error.message}`;
        });
    });
}); 