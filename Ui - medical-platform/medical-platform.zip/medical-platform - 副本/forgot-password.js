document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('forgotPasswordForm');
    const securityQuestions = document.getElementById('securityQuestions');
    const resetPasswordSection = document.getElementById('resetPasswordSection');
    const submitBtn = document.getElementById('submitBtn');
    let currentUser = null;

    // 密保问题映射
    const questionMap = {
        'father': '父亲的名字',
        'mother': '母亲的名字',
        'grandfather': '爷爷的名字',
        'grandmother': '奶奶的名字',
        'spouse': '爱人的名字',
        'pet': '第一只宠物的名字',
        'teacher': '小学班主任的名字',
        'snack': '最喜欢的零食'
    };

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const users = JSON.parse(localStorage.getItem('users')) || [];

        if (!securityQuestions.style.display || securityQuestions.style.display === 'none') {
            // 第一步：验证用户名
            currentUser = users.find(user => user.username === username);
            
            if (!currentUser) {
                alert('用户名不存在！');
                return;
            }

            // 显示密保问题
            document.getElementById('question1Text').textContent = questionMap[currentUser.securityQuestions[0].question];
            document.getElementById('question2Text').textContent = questionMap[currentUser.securityQuestions[1].question];
            document.getElementById('question3Text').textContent = questionMap[currentUser.securityQuestions[2].question];
            
            securityQuestions.style.display = 'block';
            submitBtn.textContent = '验证密保问题';
        } else if (!resetPasswordSection.style.display || resetPasswordSection.style.display === 'none') {
            // 第二步：验证密保问题
            const answer1 = document.getElementById('answer1').value;
            const answer2 = document.getElementById('answer2').value;
            const answer3 = document.getElementById('answer3').value;

            if (answer1 === currentUser.securityQuestions[0].answer &&
                answer2 === currentUser.securityQuestions[1].answer &&
                answer3 === currentUser.securityQuestions[2].answer) {
                
                resetPasswordSection.style.display = 'block';
                submitBtn.textContent = '重置密码';
            } else {
                alert('密保问题答案错误！');
            }
        } else {
            // 第三步：重置密码
            const newPassword = document.getElementById('newPassword').value;
            const confirmNewPassword = document.getElementById('confirmNewPassword').value;

            if (newPassword !== confirmNewPassword) {
                alert('两次输入的密码不一致！');
                return;
            }

            // 更新密码
            currentUser.password = newPassword;
            const userIndex = users.findIndex(user => user.username === currentUser.username);
            users[userIndex] = currentUser;
            localStorage.setItem('users', JSON.stringify(users));

            alert('密码重置成功！');
            window.location.href = 'index.html';
        }
    });
}); 