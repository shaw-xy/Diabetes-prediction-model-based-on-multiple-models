import sqlite3
import json
from werkzeug.security import generate_password_hash, check_password_hash
import os

# 获取当前目录
current_dir = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(current_dir, 'users.db')

def init_db():
    """初始化数据库，创建用户表"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # 创建用户表
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (username TEXT PRIMARY KEY,
                  password TEXT NOT NULL,
                  email TEXT,
                  phone TEXT,
                  security_questions TEXT)''')
    
    # 添加默认用户（如果不存在）
    default_users = [
        ('admin', 'admin', 'admin@example.com', '13800138000', 
         json.dumps([
             {'question': 'father', 'answer': 'John'},
             {'question': 'mother', 'answer': 'Mary'},
             {'question': 'pet', 'answer': 'Spot'}
         ])),
        ('test', 'test', 'test@example.com', '13900139000',
         json.dumps([
             {'question': 'father', 'answer': 'Tom'},
             {'question': 'mother', 'answer': 'Jane'},
             {'question': 'pet', 'answer': 'Max'}
         ]))
    ]
    
    for user in default_users:
        try:
            hashed_password = generate_password_hash(user[1])
            c.execute('''INSERT OR IGNORE INTO users 
                        (username, password, email, phone, security_questions)
                        VALUES (?, ?, ?, ?, ?)''',
                     (user[0], hashed_password, user[2], user[3], user[4]))
    
        except sqlite3.Error as e:
            print(f"Error adding default user {user[0]}: {e}")
    
    conn.commit()
    conn.close()

def get_user(username):
    """获取用户信息"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?", (username,))
    user = c.fetchone()
    conn.close()
    
    if user:
        return {
            'username': user[0],
            'password': user[1],
            'email': user[2],
            'phone': user[3],
            'security_questions': json.loads(user[4])
        }
    return None

def verify_password(username, password):
    """验证用户密码"""
    user = get_user(username)
    if user and check_password_hash(user['password'], password):
        return True
    return False

def add_user(username, password, email, phone, security_questions):
    """添加新用户"""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        hashed_password = generate_password_hash(password)
        c.execute('''INSERT INTO users 
                    (username, password, email, phone, security_questions)
                    VALUES (?, ?, ?, ?, ?)''',
                 (username, hashed_password, email, phone, json.dumps(security_questions)))
        conn.commit()
        conn.close()
        return True
    except sqlite3.Error as e:
        print(f"Error adding user {username}: {e}")
        return False

def update_password(username, new_password):
    """更新用户密码"""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        hashed_password = generate_password_hash(new_password)
        c.execute("UPDATE users SET password = ? WHERE username = ?",
                 (hashed_password, username))
        conn.commit()
        conn.close()
        return True
    except sqlite3.Error as e:
        print(f"Error updating password for user {username}: {e}")
        return False

def verify_security_info(username, email, phone, security_question, security_answer):
    """验证用户的安全信息"""
    user = get_user(username)
    if not user:
        return False
    
    if user['email'] != email or user['phone'] != phone:
        return False
    
    # 验证密保问题答案
    for qa in user['security_questions']:
        if qa['question'] == security_question and qa['answer'] == security_answer:
            return True
    
    return False

# 初始化数据库
init_db() 